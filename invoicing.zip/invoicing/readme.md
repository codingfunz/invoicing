### make nonce if needed
https://dev.to/ugorji_simon/how-to-create-a-simple-nonce-in-php-1841